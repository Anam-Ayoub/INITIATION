<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

include $_SERVER['DOCUMENT_ROOT'] . "/config/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!isset($data['username']) || !isset($data['password'])) {
    echo json_encode(['success' => false, 'error' => 'Identifiants manquants']);
    exit();
}

$username = $conn->real_escape_string($data['username']);
$password = $data['password'];

$sql = "SELECT ID_USER, PASSWORD, ROLE, REF_ID FROM USERS WHERE USERNAME = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    if (password_verify($password, $row['PASSWORD'])) {
        // Successful login
        $response = [
            'success' => true,
            'user' => [
                'id' => $row['ID_USER'],
                'username' => $username,
                'role' => $row['ROLE'],
                'ref_id' => $row['REF_ID']
            ]
        ];
        echo json_encode($response);
    } else {
        echo json_encode(['success' => false, 'error' => 'Mot de passe incorrect']);
    }
} else {
    // Check old ADMIN table as a fallback if they log in as admin
    $sqlAdmin = "SELECT ID_ADMIN, PASSWORD FROM ADMIN WHERE USERNAME = ?";
    $stmtAdmin = $conn->prepare($sqlAdmin);
    $stmtAdmin->bind_param("s", $username);
    $stmtAdmin->execute();
    $resultAdmin = $stmtAdmin->get_result();
    
    if ($rowAdmin = $resultAdmin->fetch_assoc()) {
        if (password_verify($password, $rowAdmin['PASSWORD'])) {
            echo json_encode([
                'success' => true,
                'user' => [
                    'id' => $rowAdmin['ID_ADMIN'],
                    'username' => $username,
                    'role' => 'admin',
                    'ref_id' => null
                ]
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Mot de passe incorrect']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Utilisateur introuvable']);
    }
}
?>
