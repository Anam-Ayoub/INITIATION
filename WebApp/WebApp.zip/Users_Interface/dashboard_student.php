<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$studentName = $_SESSION['STUDENT_NAME'];
$idClasse = $_SESSION['ID_CLASSE'];

// Fetch the class name
$stmtClass = $pdo->prepare("SELECT NUMERO FROM CLASSE WHERE ID_CLASSE = :id");
$stmtClass->execute(['id' => $idClasse]);
$classe = $stmtClass->fetch();
$className = $classe ? $classe['NUMERO'] : 'Unknown Class';

// Fetch schedule for this class
$sql = "
    SELECT 
        e.ID_EMPLOI,
        e.JOUR,
        e.HEURE_DEB,
        e.HEURE_FIN,
        c.NOM_COURS,
        p.NOM_PROF,
        s.NOM_SALLE
    FROM EMPLOI_DU_TEMPS e
    LEFT JOIN COURS c ON e.ID_COURS = c.ID_COURS
    LEFT JOIN PROF p ON e.ID_PROF = p.ID_PROF
    LEFT JOIN SALLE s ON e.ID_SALLE = s.ID_SALLE
    WHERE e.ID_CLASSE = :id_classe
    ORDER BY FIELD(e.JOUR, 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'), e.HEURE_DEB
";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id_classe' => $idClasse]);
$results = $stmt->fetchAll();

// Organize data by day for easy rendering
$scheduleByDay = [
    'Lundi' => [],
    'Mardi' => [],
    'Mercredi' => [],
    'Jeudi' => [],
    'Vendredi' => [],
    'Samedi' => []
];

foreach ($results as $row) {
    if (isset($scheduleByDay[$row['JOUR']])) {
        $scheduleByDay[$row['JOUR']][] = $row;
    }
}

// Time slots for week view
$timeSlots = [
    '08:30:00 - 10:30:00',
    '10:30:00 - 12:30:00',
    '14:30:00 - 16:30:00',
    '16:30:00 - 18:30:00'
];

// Helper to format time strings from DB
function formatTime($timeStr) {
    return date('H:i', strtotime($timeStr));
}

// Helper to check if a session fits a time slot roughly
function getSessionForSlot($sessions, $slotIndex) {
    $slotStarts = ['08:30:00', '10:30:00', '14:30:00', '16:30:00'];
    $slotEnds = ['10:30:00', '12:30:00', '16:30:00', '18:30:00'];
    
    $slotStart = $slotStarts[$slotIndex];
    $slotEnd = $slotEnds[$slotIndex];
    
    foreach ($sessions as $session) {
        if ($session['HEURE_DEB'] <= $slotStart && $session['HEURE_FIN'] >= $slotEnd) {
            return $session;
        }
    }
    return null;
}

// Map current PHP day to French day
$englishToFrenchDay = [
    'Monday' => 'Lundi',
    'Tuesday' => 'Mardi',
    'Wednesday' => 'Mercredi',
    'Thursday' => 'Jeudi',
    'Friday' => 'Vendredi',
    'Saturday' => 'Samedi',
    'Sunday' => 'Dimanche'
];
$currentDayEnglish = date('l');
$currentDayFrench = $englishToFrenchDay[$currentDayEnglish] ?? 'Lundi';
if ($currentDayFrench === 'Dimanche') $currentDayFrench = 'Lundi'; // Default to Monday if Sunday
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHRONOS - Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .day-view { display: none; }
        .week-view { display: none; }
        .active-view { display: block; }
        
        .day-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }

        .empty-day {
            padding: 3rem;
            text-align: center;
            color: var(--text-muted);
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="navbar">
            <div class="nav-content glass-panel" style="padding: 1rem 1.5rem;">
                <a href="#" class="nav-brand">CHRONOS</a>
                <div class="nav-user">
                    <div class="user-info">
                        👋 Bienvenue, <?php echo htmlspecialchars($studentName); ?> 
                        <span style="color: var(--text-muted); margin-left: 0.5rem;">(Classe : <?php echo htmlspecialchars($className); ?>)</span>
                    </div>
                    <a href="logout.php" class="btn-logout">Se déconnecter</a>
                </div>
            </div>
        </nav>

        <main>
            <div class="dashboard-header">
                <h2>Mon Emploi du Temps</h2>
                <div class="view-controls">
                    <button class="view-btn active" onclick="switchView('day')" id="btn-day">Aujourd'hui</button>
                    <button class="view-btn" onclick="switchView('week')" id="btn-week">Semaine</button>
                </div>
            </div>

            <!-- Day View Area -->
            <div id="view-day" class="day-view active-view glass-panel" style="padding: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                    <h3><?php echo htmlspecialchars($currentDayFrench); ?></h3>
                    <select id="day-selector" class="form-control" style="width: auto;" onchange="changeDay()">
                        <?php foreach (array_keys($scheduleByDay) as $day): ?>
                            <option value="<?php echo htmlspecialchars($day); ?>" <?php echo $day === $currentDayFrench ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($day); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php foreach ($scheduleByDay as $day => $sessions): ?>
                    <div id="day-content-<?php echo htmlspecialchars($day); ?>" class="day-grid" style="display: <?php echo $day === $currentDayFrench ? 'grid' : 'none'; ?>">
                        <?php if (empty($sessions)): ?>
                            <div class="empty-day" style="grid-column: 1 / -1; background: rgba(255,255,255,0.4); border-radius: 0.5rem; border: 1px dashed #D1D5DB;">
                                Aucun cours programmé pour ce jour.
                            </div>
                        <?php else: ?>
                            <?php foreach ($sessions as $session): ?>
                                <div class="schedule-card" style="background: white;">
                                    <div class="schedule-detail" style="font-weight: 600; color: var(--primary); margin-bottom: 0.5rem;">
                                        🕒 <?php echo formatTime($session['HEURE_DEB']) . ' - ' . formatTime($session['HEURE_FIN']); ?>
                                    </div>
                                    <div class="course-name" style="font-size: 1.1rem; margin-bottom: 0.5rem;">
                                        <?php echo htmlspecialchars($session['NOM_COURS'] ?: 'Unknown Course'); ?>
                                    </div>
                                    <div class="schedule-detail">
                                        👨‍🏫 <?php echo htmlspecialchars($session['NOM_PROF'] ?: 'Unknown Prof'); ?>
                                    </div>
                                    <div class="schedule-detail">
                                        🚪 Salle : <?php echo htmlspecialchars($session['NOM_SALLE'] ?: 'N/A'); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Week View Area -->
            <div id="view-week" class="week-view glass-panel" style="padding: 2rem;">
                <div class="timetable-container">
                    <table class="timetable-grid">
                        <thead>
                            <tr>
                                <th style="width: 120px;">Heure</th>
                                <?php foreach (array_keys($scheduleByDay) as $day): ?>
                                    <th><?php echo htmlspecialchars($day); ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($timeSlots as $slotIndex => $timeSlot): ?>
                                <?php list($startStr, $endStr) = explode(' - ', $timeSlot); ?>
                                <tr>
                                    <td style="padding: 1rem 0; font-weight: 500; color: var(--text-muted); font-size: 0.875rem;">
                                        <?php echo formatTime($startStr) . '<br>-<br>' . formatTime($endStr); ?>
                                    </td>
                                    <?php foreach ($scheduleByDay as $day => $sessions): ?>
                                        <td style="padding: 0.5rem;">
                                            <?php 
                                            $session = getSessionForSlot($sessions, $slotIndex);
                                            if ($session): 
                                            ?>
                                                <div class="schedule-card" style="background: white; border-top: 1px solid #e5e7eb; border-right: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb;">
                                                    <div class="course-name" style="font-size: 0.8rem;">
                                                        <?php echo htmlspecialchars($session['NOM_COURS'] ?: 'Unknown'); ?>
                                                    </div>
                                                    <div class="schedule-detail">
                                                        <?php echo htmlspecialchars($session['NOM_PROF'] ?: 'Unknown'); ?>
                                                    </div>
                                                    <div class="schedule-detail">
                                                        Salle: <?php echo htmlspecialchars($session['NOM_SALLE'] ?: 'N/A'); ?>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <div class="empty-slot">Libre</div>
                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>

    <script>
        function switchView(view) {
            // Update buttons
            document.getElementById('btn-day').classList.remove('active');
            document.getElementById('btn-week').classList.remove('active');
            document.getElementById('btn-' + view).classList.add('active');

            // Update views
            document.getElementById('view-day').classList.remove('active-view');
            document.getElementById('view-week').classList.remove('active-view');
            document.getElementById('view-' + view).classList.add('active-view');
        }

        function changeDay() {
            var selectedDay = document.getElementById('day-selector').value;
            var days = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
            
            days.forEach(function(day) {
                document.getElementById('day-content-' + day).style.display = 'none';
            });
            
            document.getElementById('day-content-' + selectedDay).style.display = 'grid';
        }
    </script>
</body>
</html>
